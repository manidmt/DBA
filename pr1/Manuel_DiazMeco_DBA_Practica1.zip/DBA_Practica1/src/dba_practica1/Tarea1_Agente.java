package dba_practica1;

import jade.core.Agent;

/**
 *
 * @author manidmt
 */
public class Tarea1_Agente extends Agent {

    @Override
    protected void setup(){
        System.out.println("Hola Manuel!, soy tu primer agente");
    }
}
